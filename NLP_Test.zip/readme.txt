NLP_CW_Test.ipynb

BERT model was unable to zip because of it's file size.

*** Please download the BERT models from the link below that includes three different 
files which are "bert_model.bin", "optimizer_state.bin" and "scheduler_state.bin"****

https://drive.google.com/drive/folders/10fhJLQtPm8VFZxWOHOkyqYU5LlkCBiv2?usp=sharing


Follow the following steps to test the above file:

1.	upload the folder into Google Drive

2.	Make sure make relevent changes on your filepath

3.	Open the Test Colab Notebook and run the cells